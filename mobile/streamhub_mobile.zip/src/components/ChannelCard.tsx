import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Colors } from '../constants/colors';
import { Layout } from '../constants/layout';
import { Channel } from '../types';
import { LiveBadge } from './Badge';

interface ChannelCardProps {
  channel: Channel;
  onPress: (channel: Channel) => void;
  variant?: 'default' | 'wide';
}

export function ChannelCard({ channel, onPress, variant = 'default' }: ChannelCardProps) {
  const isWide = variant === 'wide';

  return (
    <TouchableOpacity
      style={[styles.card, isWide && styles.cardWide]}
      onPress={() => onPress(channel)}
      activeOpacity={0.7}
    >
      <View style={[styles.logoContainer, isWide && styles.logoContainerWide]}>
        <Image
          source={{ uri: channel.logo }}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>
      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={1}>{channel.name}</Text>
        {channel.currentProgram ? (
          <Text style={styles.program} numberOfLines={1}>{channel.currentProgram}</Text>
        ) : null}
        {channel.isLive ? (
          <LiveBadge viewers={channel.viewers} />
        ) : null}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: Layout.channelCardWidth * 1.2,
    backgroundColor: Colors.surfaceElevated,
    borderRadius: Layout.radiusMd,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cardWide: {
    width: Layout.screenWidth * 0.7,
    flexDirection: 'row',
    alignItems: 'center',
    padding: Layout.sm,
  },
  logoContainer: {
    backgroundColor: Colors.surface,
    padding: Layout.md,
    alignItems: 'center',
    justifyContent: 'center',
    height: 70,
  },
  logoContainerWide: {
    height: 56,
    width: 80,
    borderRadius: Layout.radiusSm,
    padding: Layout.sm,
    marginRight: Layout.sm,
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  info: {
    padding: Layout.sm,
    flex: 1,
  },
  name: {
    color: Colors.textPrimary,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 3,
  },
  program: {
    color: Colors.textSecondary,
    fontSize: 11,
    marginBottom: 5,
  },
});
